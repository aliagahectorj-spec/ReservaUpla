-- ReservaUPLA - esquema de base de datos (SQLite)
-- UUID -> TEXT, VARCHAR -> TEXT, BOOLEAN -> INTEGER (0/1), DATE/TIME -> TEXT (ISO)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuario (
  id              TEXT PRIMARY KEY,
  nombre_completo TEXT NOT NULL CHECK (length(nombre_completo) <= 150),
  correo          TEXT NOT NULL UNIQUE CHECK (length(correo) <= 150),
  rol             TEXT NOT NULL CHECK (rol IN ('Solicitante','Administrador','ResponsableAmbiente')),
  activo          INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1))
);

CREATE TABLE IF NOT EXISTS ambiente (
  id         TEXT PRIMARY KEY,
  nombre     TEXT NOT NULL UNIQUE CHECK (length(nombre) <= 100),
  tipo       TEXT NOT NULL CHECK (length(tipo) <= 50),
  capacidad  INTEGER NOT NULL CHECK (capacidad > 0),
  ubicacion  TEXT NOT NULL CHECK (length(ubicacion) <= 100),
  estado     TEXT NOT NULL DEFAULT 'Disponible' CHECK (estado IN ('Disponible','Mantenimiento','Inactivo')),
  responsable_id TEXT REFERENCES usuario(id)
);

CREATE TABLE IF NOT EXISTS reserva (
  id          TEXT PRIMARY KEY,
  fecha       TEXT NOT NULL,
  hora_inicio TEXT NOT NULL,
  hora_fin    TEXT NOT NULL,
  motivo      TEXT NOT NULL,
  estado      TEXT NOT NULL DEFAULT 'Pendiente' CHECK (estado IN ('Pendiente','Aprobada','Rechazada','Cancelada')),
  usuario_id  TEXT NOT NULL REFERENCES usuario(id),
  ambiente_id TEXT NOT NULL REFERENCES ambiente(id),
  creado_en   TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (hora_fin > hora_inicio)
);

CREATE INDEX IF NOT EXISTS idx_reserva_ambiente_fecha ON reserva (ambiente_id, fecha, estado);
