import { api } from '../services/api.js';
import { validarReserva } from '../validators/reglas.js';
import { useFormulario } from '../hooks/useFormulario.js';
import TextInput from '../components/TextInput.jsx';
import SelectInput from '../components/SelectInput.jsx';
import DateInput from '../components/DateInput.jsx';
import TimeInput from '../components/TimeInput.jsx';
import Button from '../components/Button.jsx';
import AlertMessage from '../components/AlertMessage.jsx';

export default function FormReserva({ usuarios, ambientes, usuarioActual, alGuardar }) {
  const f = useFormulario({
    inicial: { usuarioId: usuarioActual?.id || '', ambienteId: '', fecha: '', horaInicio: '', horaFin: '', motivo: '' },
    validar: validarReserva,
    enviar: async (v) => { await api.reservas.crear(v); alGuardar?.(); },
  });
  const solicitantes = usuarios.filter((u) => u.activo).map((u) => ({ valor: u.id, texto: u.nombreCompleto }));
  const lugares = ambientes.filter((a) => a.estado === 'Disponible').map((a) => ({ valor: a.id, texto: `${a.nombre} (cap. ${a.capacidad})` }));

  return (
    <form className="formulario" onSubmit={f.manejarEnvio} noValidate>
      <h2>Nueva reserva</h2>
      <p className="formulario__ayuda">Las reservas se atienden de 07:00 a 22:00. El administrador debe aprobarlas.</p>
      <AlertMessage tipo={f.mensaje?.tipo} onCerrar={f.cerrarMensaje}>{f.mensaje?.texto}</AlertMessage>
      <SelectInput id="res-sol" etiqueta="Solicitante" opciones={solicitantes} value={f.valores.usuarioId} onChange={f.cambiar('usuarioId')} error={f.errores.usuarioId} />
      <SelectInput id="res-amb" etiqueta="Ambiente" opciones={lugares} value={f.valores.ambienteId} onChange={f.cambiar('ambienteId')} error={f.errores.ambienteId} />
      <DateInput id="res-fecha" etiqueta="Fecha" value={f.valores.fecha} onChange={f.cambiar('fecha')} error={f.errores.fecha} />
      <div className="fila">
        <TimeInput id="res-ini" etiqueta="Hora de inicio" min="07:00" max="22:00" value={f.valores.horaInicio} onChange={f.cambiar('horaInicio')} error={f.errores.horaInicio} />
        <TimeInput id="res-fin" etiqueta="Hora de fin" min="07:00" max="22:00" value={f.valores.horaFin} onChange={f.cambiar('horaFin')} error={f.errores.horaFin} />
      </div>
      <TextInput id="res-motivo" etiqueta="Motivo" value={f.valores.motivo} onChange={f.cambiar('motivo')} error={f.errores.motivo} />
      <Button type="submit" cargando={f.enviando}>Solicitar reserva</Button>
    </form>
  );
}
