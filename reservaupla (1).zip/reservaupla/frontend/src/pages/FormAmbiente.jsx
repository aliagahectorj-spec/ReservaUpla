import { api } from '../services/api.js';
import { validarAmbiente } from '../validators/reglas.js';
import { useFormulario } from '../hooks/useFormulario.js';
import TextInput from '../components/TextInput.jsx';
import SelectInput from '../components/SelectInput.jsx';
import Button from '../components/Button.jsx';
import AlertMessage from '../components/AlertMessage.jsx';

export default function FormAmbiente({ usuarios = [], alGuardar }) {
  const f = useFormulario({
    inicial: { nombre: '', tipo: '', capacidad: '', ubicacion: '', responsableId: '' },
    validar: validarAmbiente,
    enviar: async (v) => { await api.ambientes.crear({ ...v, capacidad: Number(v.capacidad), responsableId: v.responsableId || null }); alGuardar?.(); },
  });
  return (
    <form className="formulario" onSubmit={f.manejarEnvio} noValidate>
      <h2>Registrar ambiente</h2>
      <p className="formulario__ayuda">Laboratorios, auditorios, salas de reuniones y otros espacios reservables.</p>
      <AlertMessage tipo={f.mensaje?.tipo} onCerrar={f.cerrarMensaje}>{f.mensaje?.texto}</AlertMessage>
      <TextInput id="amb-nombre" etiqueta="Nombre" value={f.valores.nombre} onChange={f.cambiar('nombre')} error={f.errores.nombre} />
      <TextInput id="amb-tipo" etiqueta="Tipo (laboratorio, auditorio, sala…)" value={f.valores.tipo} onChange={f.cambiar('tipo')} error={f.errores.tipo} />
      <TextInput id="amb-cap" etiqueta="Capacidad" tipo="number" min="1" value={f.valores.capacidad} onChange={f.cambiar('capacidad')} error={f.errores.capacidad} />
      <TextInput id="amb-ubi" etiqueta="Ubicación" value={f.valores.ubicacion} onChange={f.cambiar('ubicacion')} error={f.errores.ubicacion} />
      <SelectInput id="amb-resp" etiqueta="Responsable del ambiente (opcional)" placeholder="Sin asignar"
        opciones={usuarios.filter((u) => u.rol === 'ResponsableAmbiente' && u.activo).map((u) => ({ valor: u.id, texto: u.nombreCompleto }))}
        value={f.valores.responsableId} onChange={f.cambiar('responsableId')} error={f.errores.responsableId} />
      <Button type="submit" cargando={f.enviando}>Guardar ambiente</Button>
    </form>
  );
}
