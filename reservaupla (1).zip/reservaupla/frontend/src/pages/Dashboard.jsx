import { useEffect, useState } from 'react';
import { api } from '../services/api.js';
import CardIndicador from '../components/CardIndicador.jsx';
import AlertMessage from '../components/AlertMessage.jsx';
import EncabezadoPagina from '../components/EncabezadoPagina.jsx';

const SEGMENTOS = [
  ['pendientes', 'Pendientes', 'pendiente'],
  ['aprobadas', 'Aprobadas', 'aprobada'],
  ['rechazadas', 'Rechazadas', 'rechazada'],
  ['canceladas', 'Canceladas', 'cancelada'],
];
const hoy = new Date().toLocaleDateString('es-PE', { weekday: 'long', day: 'numeric', month: 'long' });

export default function Dashboard() {
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => { api.reservas.indicadores().then(setDatos).catch((e) => setError(e.message)); }, []);

  if (error) return <AlertMessage tipo="error">{error}</AlertMessage>;
  if (!datos) return <p className="cargando">Cargando indicadores…</p>;

  const top = datos.ambienteMasUtilizado;
  return (
    <section>
      <EncabezadoPagina titulo="Panel general" descripcion="Resumen de la actividad de reservas de la universidad.">
        <span className="fecha-hoy">{hoy}</span>
      </EncabezadoPagina>

      <div className="portada">
        <p className="portada__etiqueta">Ambiente más utilizado</p>
        <h3 className="portada__titulo">{top ? top.nombre : 'Aún sin reservas'}</h3>
        <p className="portada__detalle">
          {top ? `${top.reservas} ${top.reservas === 1 ? 'reserva registrada' : 'reservas registradas'} en total` : 'Registre una reserva para ver qué ambiente se usa más.'}
        </p>
      </div>

      <div className="indicadores">
        <CardIndicador titulo="Total de reservas" valor={datos.total} icono="total" />
        <CardIndicador titulo="Pendientes" valor={datos.pendientes} color="pendiente" icono="pendiente" />
        <CardIndicador titulo="Aprobadas" valor={datos.aprobadas} color="aprobada" icono="aprobada" />
        <CardIndicador titulo="Rechazadas" valor={datos.rechazadas} color="rechazada" icono="rechazada" />
      </div>

      <div className="distribucion">
        <h3>Distribución por estado</h3>
        {datos.total === 0 ? (
          <p className="distribucion__vacio">Todavía no hay reservas para mostrar.</p>
        ) : (
          <>
            <div className="distribucion__barra" role="img" aria-label="Proporción de reservas por estado">
              {SEGMENTOS.map(([clave, , color]) => datos[clave] > 0 && (
                <span key={clave} className={`seg seg--${color}`} style={{ flexGrow: datos[clave] }} />
              ))}
            </div>
            <ul className="distribucion__leyenda">
              {SEGMENTOS.map(([clave, texto, color]) => (
                <li key={clave}><i className={`punto punto--${color}`} />{texto} <strong>{datos[clave]}</strong> <span>{Math.round((datos[clave] / datos.total) * 100)}%</span></li>
              ))}
            </ul>
          </>
        )}
      </div>
    </section>
  );
}
