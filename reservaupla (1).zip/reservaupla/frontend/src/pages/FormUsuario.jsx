import { api } from '../services/api.js';
import { validarUsuario } from '../validators/reglas.js';
import { useFormulario } from '../hooks/useFormulario.js';
import TextInput from '../components/TextInput.jsx';
import SelectInput from '../components/SelectInput.jsx';
import Button from '../components/Button.jsx';
import AlertMessage from '../components/AlertMessage.jsx';

const ROLES = ['Solicitante', 'Administrador', 'ResponsableAmbiente'].map((r) => ({ valor: r, texto: r === 'ResponsableAmbiente' ? 'Responsable de ambiente' : r }));

export default function FormUsuario({ alGuardar }) {
  const f = useFormulario({
    inicial: { nombreCompleto: '', correo: '', rol: 'Solicitante' },
    validar: validarUsuario,
    enviar: async (v) => { await api.usuarios.crear(v); alGuardar?.(); },
  });
  return (
    <form className="formulario" onSubmit={f.manejarEnvio} noValidate>
      <h2>Registrar usuario</h2>
      <p className="formulario__ayuda">Solicitantes, administradores y responsables de ambiente.</p>
      <AlertMessage tipo={f.mensaje?.tipo} onCerrar={f.cerrarMensaje}>{f.mensaje?.texto}</AlertMessage>
      <TextInput id="nombre" etiqueta="Nombre completo" value={f.valores.nombreCompleto} onChange={f.cambiar('nombreCompleto')} error={f.errores.nombreCompleto} />
      <TextInput id="correo" etiqueta="Correo institucional" tipo="email" value={f.valores.correo} onChange={f.cambiar('correo')} error={f.errores.correo} />
      <SelectInput id="rol" etiqueta="Rol" opciones={ROLES} value={f.valores.rol} onChange={f.cambiar('rol')} error={f.errores.rol} />
      <Button type="submit" cargando={f.enviando}>Guardar usuario</Button>
    </form>
  );
}
