import { useCallback, useEffect, useState } from 'react';
import { api } from '../services/api.js';
import TableList from '../components/TableList.jsx';
import EstadoBadge from '../components/EstadoBadge.jsx';
import Button from '../components/Button.jsx';
import AlertMessage from '../components/AlertMessage.jsx';
import SelectInput from '../components/SelectInput.jsx';
import ModalConfirmacion from '../components/ModalConfirmacion.jsx';
import EncabezadoPagina from '../components/EncabezadoPagina.jsx';

const ESTADOS = ['Pendiente', 'Aprobada', 'Rechazada', 'Cancelada'].map((e) => ({ valor: e, texto: e }));

export default function ListaReservas({ usuarioActual }) {
  const [reservas, setReservas] = useState([]);
  const [filtro, setFiltro] = useState('');
  const [detalle, setDetalle] = useState(null);
  const [pendienteAccion, setPendienteAccion] = useState(null); // { reserva, estado }
  const [mensaje, setMensaje] = useState(null);

  const esResponsable = usuarioActual?.rol === 'ResponsableAmbiente';
  const responsableId = esResponsable ? usuarioActual.id : '';

  const cargar = useCallback(() => {
    api.reservas.listar({ estado: filtro, responsableId }).then(setReservas).catch((e) => setMensaje({ tipo: 'error', texto: e.message }));
  }, [filtro, responsableId]);
  useEffect(cargar, [cargar]);

  const esAdmin = usuarioActual?.rol === 'Administrador';

  async function confirmar() {
    const { reserva, estado } = pendienteAccion;
    setPendienteAccion(null);
    try {
      await api.reservas.cambiarEstado(reserva.id, estado);
      setMensaje({ tipo: 'exito', texto: `Reserva ${estado.toLowerCase()}.` });
      setDetalle(null);
      cargar();
    } catch (e) {
      setMensaje({ tipo: 'error', texto: e.message });
    }
  }

  const acciones = (r) => {
    const botones = [];
    if (r.estado === 'Pendiente' && esAdmin) {
      botones.push(<Button key="a" onClick={() => setPendienteAccion({ reserva: r, estado: 'Aprobada' })}>Aprobar</Button>);
      botones.push(<Button key="r" variante="peligro" onClick={() => setPendienteAccion({ reserva: r, estado: 'Rechazada' })}>Rechazar</Button>);
    }
    if (['Pendiente', 'Aprobada'].includes(r.estado) && (esAdmin || usuarioActual?.id === r.usuarioId))
      botones.push(<Button key="c" variante="secundario" onClick={() => setPendienteAccion({ reserva: r, estado: 'Cancelada' })}>Cancelar</Button>);
    return botones;
  };

  const columnas = [
    { clave: 'fecha', titulo: 'Fecha' },
    { clave: 'horario', titulo: 'Horario', render: (r) => <span className="hora">{r.horaInicio} – {r.horaFin}</span> },
    { clave: 'ambienteNombre', titulo: 'Ambiente', render: (r) => <strong>{r.ambienteNombre}</strong> },
    { clave: 'usuarioNombre', titulo: 'Solicitante', render: (r) => <span className="persona"><span className="avatar">{r.usuarioNombre[0]}</span>{r.usuarioNombre}</span> },
    { clave: 'estado', titulo: 'Estado', render: (r) => <EstadoBadge estado={r.estado} /> },
    { clave: 'detalle', titulo: '', render: (r) => <Button variante="enlace" onClick={() => setDetalle(r)}>Ver detalle</Button> },
  ];

  return (
    <section>
      <EncabezadoPagina titulo="Reservas" descripcion="Consulte, apruebe, rechace o cancele las solicitudes registradas." />
      <AlertMessage tipo={mensaje?.tipo} onCerrar={() => setMensaje(null)}>{mensaje?.texto}</AlertMessage>
      {esResponsable && <AlertMessage tipo="info">Mostrando solo las reservas de los ambientes asignados a usted.</AlertMessage>}
      <div className="filtros">
        <SelectInput id="filtro" etiqueta="Filtrar por estado" placeholder="Todos" opciones={ESTADOS} value={filtro} onChange={(e) => setFiltro(e.target.value)} />
      </div>
      <TableList columnas={columnas} filas={reservas} vacio="Aún no hay reservas. Cree la primera desde “Nueva reserva”." />

      {detalle && (
        <aside className="detalle" aria-label="Detalle de la reserva">
          <h3>Detalle de la reserva</h3>
          <dl>
            <dt>Ambiente</dt><dd>{detalle.ambienteNombre}</dd>
            <dt>Solicitante</dt><dd>{detalle.usuarioNombre}</dd>
            <dt>Fecha</dt><dd>{detalle.fecha}</dd>
            <dt>Horario</dt><dd>{detalle.horaInicio} – {detalle.horaFin}</dd>
            <dt>Motivo</dt><dd>{detalle.motivo}</dd>
            <dt>Estado</dt><dd><EstadoBadge estado={detalle.estado} /></dd>
            <dt>Registrada</dt><dd>{detalle.creadoEn}</dd>
          </dl>
          <div className="detalle__acciones">{acciones(detalle)}<Button variante="secundario" onClick={() => setDetalle(null)}>Cerrar</Button></div>
        </aside>
      )}

      <ModalConfirmacion
        abierto={!!pendienteAccion}
        titulo={`${pendienteAccion?.estado === 'Aprobada' ? 'Aprobar' : pendienteAccion?.estado === 'Rechazada' ? 'Rechazar' : 'Cancelar'} reserva`}
        mensaje={pendienteAccion ? `¿Confirma cambiar la reserva de ${pendienteAccion.reserva.ambienteNombre} (${pendienteAccion.reserva.fecha}) a “${pendienteAccion.estado}”?` : ''}
        textoConfirmar="Sí, confirmar"
        onConfirmar={confirmar}
        onCancelar={() => setPendienteAccion(null)}
      />
    </section>
  );
}
