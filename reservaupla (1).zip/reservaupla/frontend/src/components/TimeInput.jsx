import TextInput from './TextInput.jsx';

export default function TimeInput(props) {
  return <TextInput tipo="time" {...props} />;
}
