export default function Button({ variante = 'primario', cargando = false, children, ...props }) {
  return (
    <button className={`btn btn--${variante}`} disabled={cargando || props.disabled} {...props}>
      {cargando ? 'Procesando…' : children}
    </button>
  );
}
