export default function EncabezadoPagina({ titulo, descripcion, children }) {
  return (
    <header className="pagina">
      <div>
        <h2>{titulo}</h2>
        {descripcion && <p>{descripcion}</p>}
      </div>
      {children}
    </header>
  );
}
