import Button from './Button.jsx';

export default function ModalConfirmacion({ abierto, titulo, mensaje, onConfirmar, onCancelar, textoConfirmar = 'Confirmar' }) {
  if (!abierto) return null;
  return (
    <div className="modal__fondo" onClick={onCancelar}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-titulo" onClick={(e) => e.stopPropagation()}>
        <h3 id="modal-titulo">{titulo}</h3>
        <p>{mensaje}</p>
        <div className="modal__acciones">
          <Button variante="secundario" onClick={onCancelar}>Volver</Button>
          <Button onClick={onConfirmar}>{textoConfirmar}</Button>
        </div>
      </div>
    </div>
  );
}
