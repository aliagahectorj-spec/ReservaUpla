import Icono from './Icono.jsx';

// columnas: [{ clave, titulo, render?(fila) }]
export default function TableList({ columnas, filas, vacio = 'No hay registros para mostrar.' }) {
  if (!filas.length) {
    return (
      <div className="vacio">
        <span className="vacio__icono"><Icono nombre="reservas" tam={28} /></span>
        <p>{vacio}</p>
      </div>
    );
  }
  return (
    <div className="tabla__contenedor">
      <table className="tabla">
        <thead><tr>{columnas.map((c) => <th key={c.clave}>{c.titulo}</th>)}</tr></thead>
        <tbody>
          {filas.map((f) => (
            <tr key={f.id}>{columnas.map((c) => <td key={c.clave}>{c.render ? c.render(f) : f[c.clave]}</td>)}</tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
