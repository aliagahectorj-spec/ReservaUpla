import Campo from './Campo.jsx';

export default function SelectInput({ id, etiqueta, error, opciones, placeholder = 'Seleccione…', ...props }) {
  return (
    <Campo id={id} etiqueta={etiqueta} error={error}>
      <select id={id} aria-invalid={!!error} {...props}>
        <option value="">{placeholder}</option>
        {opciones.map((o) => <option key={o.valor} value={o.valor}>{o.texto}</option>)}
      </select>
    </Campo>
  );
}
