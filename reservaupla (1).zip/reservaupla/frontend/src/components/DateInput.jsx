import TextInput from './TextInput.jsx';

export default function DateInput(props) {
  return <TextInput tipo="date" {...props} />;
}
