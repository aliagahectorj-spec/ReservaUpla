// Envoltorio común de etiqueta + error para todos los campos
export default function Campo({ id, etiqueta, error, children }) {
  return (
    <div className={`campo ${error ? 'campo--error' : ''}`}>
      <label htmlFor={id}>{etiqueta}</label>
      {children}
      {error && <span className="campo__error" role="alert">{error}</span>}
    </div>
  );
}
