import Campo from './Campo.jsx';

export default function TextInput({ id, etiqueta, error, tipo = 'text', ...props }) {
  return (
    <Campo id={id} etiqueta={etiqueta} error={error}>
      <input id={id} type={tipo} aria-invalid={!!error} {...props} />
    </Campo>
  );
}
