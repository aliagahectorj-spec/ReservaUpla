import Icono from './Icono.jsx';

export default function CardIndicador({ titulo, valor, detalle, color = 'neutro', icono }) {
  return (
    <div className={`indicador indicador--${color}`}>
      {icono && <span className="indicador__icono"><Icono nombre={icono} tam={22} /></span>}
      <div>
        <p className="indicador__valor">{valor}</p>
        <p className="indicador__titulo">{titulo}</p>
        {detalle && <p className="indicador__detalle">{detalle}</p>}
      </div>
    </div>
  );
}
