export default function AlertMessage({ tipo = 'info', onCerrar, children }) {
  if (!children) return null;
  return (
    <div className={`alerta alerta--${tipo}`} role={tipo === 'error' ? 'alert' : 'status'}>
      <span>{children}</span>
      {onCerrar && <button className="alerta__cerrar" onClick={onCerrar} aria-label="Cerrar mensaje">×</button>}
    </div>
  );
}
