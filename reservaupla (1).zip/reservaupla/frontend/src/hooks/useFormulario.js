import { useState } from 'react';

// Hook reutilizable: estado, validación y envío de cualquier formulario.
export function useFormulario({ inicial, validar, enviar }) {
  const [valores, setValores] = useState(inicial);
  const [errores, setErrores] = useState({});
  const [mensaje, setMensaje] = useState(null); // { tipo, texto }
  const [enviando, setEnviando] = useState(false);

  const cambiar = (campo) => (e) => {
    setValores((v) => ({ ...v, [campo]: e.target.value }));
    setErrores((er) => ({ ...er, [campo]: undefined }));
  };

  async function manejarEnvio(e) {
    e.preventDefault();
    const errs = validar(valores);
    setErrores(errs);
    if (Object.keys(errs).length) return setMensaje({ tipo: 'error', texto: 'Revise los campos marcados.' });
    setEnviando(true);
    try {
      await enviar(valores);
      setMensaje({ tipo: 'exito', texto: 'Registro guardado correctamente.' });
      setValores(inicial);
    } catch (err) {
      const delBackend = {};
      (err.detalles || []).forEach((d) => { delBackend[d.campo] = d.mensaje; });
      setErrores(delBackend);
      setMensaje({ tipo: 'error', texto: err.message });
    } finally {
      setEnviando(false);
    }
  }

  return { valores, errores, mensaje, enviando, cambiar, manejarEnvio, cerrarMensaje: () => setMensaje(null) };
}
