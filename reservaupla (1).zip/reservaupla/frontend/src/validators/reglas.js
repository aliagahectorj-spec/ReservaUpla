// Validaciones del frontend (espejo de las del backend). Devuelven { campo: mensaje }.
const HORA_MIN = '07:00', HORA_MAX = '22:00';
const hoy = () => new Date().toISOString().slice(0, 10);

export function validarUsuario(v) {
  const e = {};
  if (!v.nombreCompleto.trim()) e.nombreCompleto = 'El nombre es obligatorio.';
  else if (v.nombreCompleto.trim().length > 150) e.nombreCompleto = 'Máximo 150 caracteres.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.correo)) e.correo = 'Ingrese un correo válido.';
  if (!v.rol) e.rol = 'Seleccione un rol.';
  return e;
}

export function validarAmbiente(v) {
  const e = {};
  if (!v.nombre.trim()) e.nombre = 'El nombre es obligatorio.';
  if (!v.tipo.trim()) e.tipo = 'El tipo es obligatorio.';
  if (!Number.isInteger(Number(v.capacidad)) || Number(v.capacidad) <= 0) e.capacidad = 'Ingrese un entero mayor a 0.';
  if (!v.ubicacion.trim()) e.ubicacion = 'La ubicación es obligatoria.';
  return e;
}

export function validarReserva(v) {
  const e = {};
  if (!v.usuarioId) e.usuarioId = 'Seleccione el solicitante.';
  if (!v.ambienteId) e.ambienteId = 'Seleccione el ambiente.';
  if (!v.fecha) e.fecha = 'Seleccione la fecha.';
  else if (v.fecha < hoy()) e.fecha = 'La fecha no puede ser anterior a hoy.';
  if (!v.horaInicio) e.horaInicio = 'Indique la hora de inicio.';
  if (!v.horaFin) e.horaFin = 'Indique la hora de fin.';
  if (v.horaInicio && v.horaFin) {
    if (v.horaFin <= v.horaInicio) e.horaFin = 'La hora de fin debe ser mayor que la de inicio.';
    if (v.horaInicio < HORA_MIN || v.horaFin > HORA_MAX) e.horaInicio = `Solo entre ${HORA_MIN} y ${HORA_MAX}.`;
  }
  if (!v.motivo.trim()) e.motivo = 'El motivo es obligatorio.';
  return e;
}
