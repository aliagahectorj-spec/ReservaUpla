# 04. Informe técnico breve – ReservaUPLA

## Arquitectura
SPA React (Vite) ⇄ API REST Express ⇄ SQLite. Capas del backend: routes → controllers → services → db.

## Cobertura de requerimientos
| Código | Dónde se cumple |
|---|---|
| RF-01 | `POST /api/usuarios` · pantalla «Usuarios» |
| RF-02 | `POST /api/ambientes` · pantalla «Ambientes» |
| RF-03 | `POST /api/reservas` · pantalla «Nueva reserva» |
| RF-04 | `reserva.service.js › hayConflicto()` se ejecuta antes de insertar |
| RF-05 | `GET /api/reservas` (filtro por estado) · «Reservas» |
| RF-06 | `GET /api/reservas/:id` · botón «Ver detalle» |
| RF-07 | `PATCH /api/reservas/:id/estado` · botones Aprobar/Rechazar/Cancelar con modal |
| RF-08 | `GET /api/reservas/indicadores` · «Dashboard» |
| RN-01 | `hayConflicto()` al crear y al aprobar |
| RN-02/03/04 | `validators/reserva.validator.js` y `frontend/src/validators/reglas.js` |
| RN-05 | `cambiarEstado()`: 403 si el actor no es Administrador |
| RN-06 | `cambiarEstado()` y `actualizar()`: 409 si la reserva está Rechazada |

## Evidencia de validaciones
Ejecutar `cd backend && npm test`: 7 pruebas automáticas cubren RN-01 a RN-06 y los indicadores. Para capturas, intente en la interfaz registrar una reserva con fin menor al inicio, fuera de 07:00–22:00 o sin motivo.

## Reflexión final
**Estándares.** Nombres, carpetas y commits comunes hacen que cualquier integrante entienda dónde está cada cosa y por qué cambió; reducen el tiempo de lectura y los errores por interpretación.

**Validación de datos.** Validar en frontend mejora la experiencia (respuesta inmediata) y en backend garantiza la integridad aunque alguien llame a la API directamente. Así RN-01 a RN-06 se cumplen siempre y la base de datos no recibe información inconsistente.

**Reutilización de componentes.** `TextInput`, `SelectInput`, `Button`, `AlertMessage`, `TableList`, etc. y el hook `useFormulario` evitan duplicar código; un cambio visual o de comportamiento se hace en un solo lugar y las pantallas se mantienen coherentes.

**Refinamiento de código.** Separar controladores, servicios y validadores, eliminar duplicación y documentar reglas reduce la deuda técnica; el código queda más fácil de probar y de modificar.

**Conjunto.** Estas prácticas elevan la **calidad** (menos defectos), la **mantenibilidad** (cambios localizados y comprensibles) y la **evolución** (agregar autenticación, notificaciones o calendario sin reescribir lo existente).
