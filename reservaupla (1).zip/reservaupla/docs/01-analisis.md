# 01. Análisis del problema (Semana 01)

## Problema
La Universidad Peruana Los Andes gestiona sus ambientes (laboratorios, auditorios, salas) por mensajes, llamadas y papel. Consecuencias: reservas duplicadas, solicitudes perdidas, ausencia de trazabilidad y desconocimiento de la disponibilidad real.

## Objetivo
Construir **ReservaUPLA**, una aplicación web para registrar, validar, consultar y visualizar reservas de ambientes.

## Actores
| Actor | Necesidad | Funciones en el sistema |
|---|---|---|
| Solicitante | Pedir un ambiente y saber su estado | Registrar y cancelar sus reservas |
| Administrador | Evitar cruces y decidir | Aprobar, rechazar, cancelar; ver dashboard |
| Responsable de ambiente | Conocer el uso del ambiente asignado | Consultar reservas |

## Alcance
**Incluye:** RF-01 a RF-08 y RN-01 a RN-06 del caso práctico (usuarios, ambientes, reservas, validación de disponibilidad, listado, detalle, cambio de estado, dashboard).

**No incluye (fuera del alcance del prototipo):** autenticación con contraseña, notificaciones por correo, reservas recurrentes, calendario gráfico, reportes en PDF.

## Supuestos
- La identidad del usuario se simula con un selector «Usuario actual» (cabecera `x-usuario-id`).
- Una reserva solo bloquea el ambiente cuando está **Aprobada** (RN-01); las pendientes pueden coexistir.
- Se considera cruce cuando `inicio_nuevo < fin_existente` y `fin_nuevo > inicio_existente` (horarios contiguos no se cruzan).
