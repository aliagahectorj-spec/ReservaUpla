# 03. Manual de estándares del proyecto (Semana 03)

## Nombres
| Elemento | Convención | Ejemplo |
|---|---|---|
| Variables y funciones JS | camelCase | `horaInicio`, `cambiarEstado()` |
| Componentes React | PascalCase | `TextInput.jsx` |
| Constantes | MAYÚSCULAS_CON_GUION | `HORARIO` |
| Tablas y columnas SQL | snake_case | `hora_inicio` |
| Rutas REST | sustantivos en plural | `/api/reservas/:id/estado` |
| Idioma | Dominio en español, términos técnicos en inglés estándar |  |

## Estructura de carpetas
```
backend/src/{config,controllers,services,validators,routes,middlewares,utils}
backend/tests
database/schema.sql
frontend/src/{components,pages,hooks,services,validators}
docs/
```
Responsabilidades: **routes** definen endpoints → **controllers** manejan HTTP → **services** contienen reglas de negocio → **db** persiste. Los **validators** no conocen HTTP.

## Codificación
- Indentación de 2 espacios, comillas simples, punto y coma, líneas ≤ 120 caracteres.
- Funciones pequeñas con una sola responsabilidad; sin números ni textos mágicos (usar `config/constants.js`).
- Comentar el *por qué* y citar la regla (`// RN-01`) donde se implemente.
- Errores de negocio con `AppError` y código HTTP correcto (422 datos inválidos, 403 permiso, 404 no existe, 409 conflicto).

## Git
- Ramas: `main` (estable), `develop` (integración), `feature/<tema>`, `fix/<tema>`.
- Commits (Conventional Commits): `feat: registrar reservas`, `fix: validar hora fin`, `docs: manual de estándares`, `refactor: extraer useFormulario`, `test: reglas RN-01`.
- Un commit = un cambio lógico; fusionar a `develop` solo con `npm test` en verde.
