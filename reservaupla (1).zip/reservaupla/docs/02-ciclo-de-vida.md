# 02. Ciclo de vida seleccionado (Semana 02)

## Modelo elegido: Incremental con entregas semanales
El proyecto se divide en incrementos alineados con las semanas del curso:

| Incremento | Contenido |
|---|---|
| 1 | Análisis, ciclo de vida y estándares (documentos) |
| 2 | Estructura de backend, frontend y base de datos |
| 3 | Formularios de entrada (usuarios, ambientes, reservas) |
| 4 | Validaciones frontend y backend |
| 5 | Componentes reutilizables y refactorización |
| 6 | Listado, detalle y dashboard |

## Justificación
- **Requisitos estables y bien definidos** (RF/RN ya listados), por lo que no se necesita la exploración de un modelo en espiral.
- **Entrega parcial verificable cada semana**, como exige la tabla de evidencias del caso.
- **Equipo pequeño y plazo corto**: cascada puro retrasaría la detección de errores hasta el final.
- **Riesgo bajo y controlado**: cada incremento se prueba (`npm test`) antes de continuar.
- Permite **refinar** el código en la semana 08 sin rehacer lo anterior.

## Modelos descartados
- *Cascada*: poca retroalimentación temprana.
- *Scrum completo*: exige roles y ceremonias que exceden un trabajo individual.
