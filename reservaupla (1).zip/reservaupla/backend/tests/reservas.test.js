// Evidencia de validaciones y reglas de negocio. Ejecutar: npm test
import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

process.env.DB_FILE = path.join(mkdtempSync(path.join(tmpdir(), 'upla-')), 'test.db');
const { app } = await import('../src/app.js');

let server, base, admin, solicitante, ambiente;
const manana = new Date(Date.now() + 86400000).toISOString().slice(0, 10);

async function api(metodo, ruta, cuerpo, actorId) {
  const res = await fetch(base + ruta, {
    method: metodo,
    headers: { 'Content-Type': 'application/json', ...(actorId ? { 'x-usuario-id': actorId } : {}) },
    body: cuerpo ? JSON.stringify(cuerpo) : undefined,
  });
  return { status: res.status, data: await res.json() };
}
const reserva = (extra = {}) => ({ fecha: manana, horaInicio: '08:00', horaFin: '10:00', motivo: 'Clase', usuarioId: solicitante.id, ambienteId: ambiente.id, ...extra });

before(async () => {
  server = app.listen(0);
  base = `http://localhost:${server.address().port}/api`;
  admin = (await api('POST', '/usuarios', { nombreCompleto: 'Admin', correo: 'a@upla.edu.pe', rol: 'Administrador' })).data;
  solicitante = (await api('POST', '/usuarios', { nombreCompleto: 'Sol', correo: 's@upla.edu.pe', rol: 'Solicitante' })).data;
  ambiente = (await api('POST', '/ambientes', { nombre: 'Lab 1', tipo: 'Laboratorio', capacidad: 20, ubicacion: 'B2' })).data;
});

test('RN-03: hora fin debe ser mayor que hora inicio', async () => {
  const r = await api('POST', '/reservas', reserva({ horaInicio: '10:00', horaFin: '09:00' }));
  assert.equal(r.status, 422);
});

test('RN-04: fuera del horario 07:00-22:00 se rechaza', async () => {
  assert.equal((await api('POST', '/reservas', reserva({ horaInicio: '06:00', horaFin: '08:00' }))).status, 422);
  assert.equal((await api('POST', '/reservas', reserva({ horaInicio: '21:00', horaFin: '23:00' }))).status, 422);
});

test('RN-02: campos obligatorios', async () => {
  assert.equal((await api('POST', '/reservas', reserva({ motivo: '' }))).status, 422);
});

test('RN-05: un solicitante no puede aprobar', async () => {
  const { data } = await api('POST', '/reservas', reserva({ horaInicio: '11:00', horaFin: '12:00' }));
  const r = await api('PATCH', `/reservas/${data.id}/estado`, { estado: 'Aprobada' }, solicitante.id);
  assert.equal(r.status, 403);
});

test('RN-01 y RF-04: no hay dos reservas aprobadas que se crucen', async () => {
  const a = (await api('POST', '/reservas', reserva({ horaInicio: '14:00', horaFin: '16:00' }))).data;
  assert.equal((await api('PATCH', `/reservas/${a.id}/estado`, { estado: 'Aprobada' }, admin.id)).status, 200);
  const choque = await api('POST', '/reservas', reserva({ horaInicio: '15:00', horaFin: '17:00' }));
  assert.equal(choque.status, 409);
  // horario contiguo sí es válido
  assert.equal((await api('POST', '/reservas', reserva({ horaInicio: '16:00', horaFin: '17:00' }))).status, 201);
});

test('RN-06: una reserva rechazada no se modifica', async () => {
  const { data } = await api('POST', '/reservas', reserva({ horaInicio: '18:00', horaFin: '19:00' }));
  await api('PATCH', `/reservas/${data.id}/estado`, { estado: 'Rechazada' }, admin.id);
  assert.equal((await api('PATCH', `/reservas/${data.id}/estado`, { estado: 'Aprobada' }, admin.id)).status, 409);
  assert.equal((await api('PUT', `/reservas/${data.id}`, { motivo: 'otro' })).status, 409);
});

test('Responsable de ambiente: solo ve las reservas de su ambiente', async () => {
  const resp = (await api('POST', '/usuarios', { nombreCompleto: 'Resp', correo: 'r@upla.edu.pe', rol: 'ResponsableAmbiente' })).data;
  const otro = (await api('POST', '/ambientes', { nombre: 'Lab 2', tipo: 'Laboratorio', capacidad: 10, ubicacion: 'B3', responsableId: resp.id })).data;
  await api('POST', '/reservas', reserva({ ambienteId: otro.id, horaInicio: '09:00', horaFin: '10:00' }));
  const { data } = await api('GET', `/reservas?responsableId=${resp.id}`);
  assert.equal(data.length, 1);
  assert.equal(data[0].ambienteNombre, 'Lab 2');
});

test('RF-08: indicadores', async () => {
  const { data } = await api('GET', '/reservas/indicadores');
  assert.ok(data.total >= 4);
  assert.equal(data.ambienteMasUtilizado.nombre, 'Lab 1');
  assert.equal(data.aprobadas, 1);
});

test.after(() => server.close());
