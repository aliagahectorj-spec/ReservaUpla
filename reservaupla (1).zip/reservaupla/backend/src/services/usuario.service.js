import { randomUUID } from 'node:crypto';
import { db } from '../db.js';
import { AppError } from '../utils/AppError.js';
import { validarUsuario } from '../validators/usuario.validator.js';

const mapear = (r) => r && ({ id: r.id, nombreCompleto: r.nombre_completo, correo: r.correo, rol: r.rol, activo: !!r.activo });

export const listar = () => db.prepare('SELECT * FROM usuario ORDER BY nombre_completo').all().map(mapear);

export const obtener = (id) => mapear(db.prepare('SELECT * FROM usuario WHERE id = ?').get(id));

export function crear(datos) {
  const errores = validarUsuario(datos);
  if (errores.length) throw new AppError('Datos de usuario no válidos.', 422, errores);
  const correo = datos.correo.trim().toLowerCase();
  if (db.prepare('SELECT 1 FROM usuario WHERE correo = ?').get(correo))
    throw new AppError('Ya existe un usuario con ese correo.', 409, [{ campo: 'correo', mensaje: 'Correo ya registrado.' }]);
  const id = randomUUID();
  db.prepare('INSERT INTO usuario (id, nombre_completo, correo, rol, activo) VALUES (?,?,?,?,1)')
    .run(id, datos.nombreCompleto.trim(), correo, datos.rol);
  return obtener(id);
}
