import { randomUUID } from 'node:crypto';
import { db } from '../db.js';
import { AppError } from '../utils/AppError.js';
import { ESTADOS_RESERVA as E, ROLES } from '../config/constants.js';
import { validarReserva } from '../validators/reserva.validator.js';
import * as usuarios from './usuario.service.js';
import * as ambientes from './ambiente.service.js';

const SELECT = `
  SELECT r.*, u.nombre_completo AS usuario_nombre, a.nombre AS ambiente_nombre
  FROM reserva r
  JOIN usuario u ON u.id = r.usuario_id
  JOIN ambiente a ON a.id = r.ambiente_id`;

const mapear = (r) => r && ({
  id: r.id, fecha: r.fecha, horaInicio: r.hora_inicio, horaFin: r.hora_fin, motivo: r.motivo, estado: r.estado,
  usuarioId: r.usuario_id, ambienteId: r.ambiente_id, usuarioNombre: r.usuario_nombre, ambienteNombre: r.ambiente_nombre, creadoEn: r.creado_en,
});

export function listar({ estado, ambienteId, fecha, responsableId } = {}) {
  const filtros = [], params = [];
  if (estado) { filtros.push('r.estado = ?'); params.push(estado); }
  if (ambienteId) { filtros.push('r.ambiente_id = ?'); params.push(ambienteId); }
  if (fecha) { filtros.push('r.fecha = ?'); params.push(fecha); }
  if (responsableId) { filtros.push('a.responsable_id = ?'); params.push(responsableId); } // Responsable: solo su ambiente
  const where = filtros.length ? `WHERE ${filtros.join(' AND ')}` : '';
  return db.prepare(`${SELECT} ${where} ORDER BY r.fecha DESC, r.hora_inicio`).all(...params).map(mapear);
}

export function obtener(id) {
  const r = mapear(db.prepare(`${SELECT} WHERE r.id = ?`).get(id));
  if (!r) throw new AppError('La reserva no existe.', 404);
  return r;
}

// RF-04 / RN-01: ¿existe otra reserva APROBADA que se cruce en el mismo ambiente, fecha y horario?
export function hayConflicto({ ambienteId, fecha, horaInicio, horaFin, excluirId = null }) {
  const fila = db.prepare(`
    SELECT 1 FROM reserva
    WHERE ambiente_id = ? AND fecha = ? AND estado = ?
      AND hora_inicio < ? AND hora_fin > ? AND id != ?`)
    .get(ambienteId, fecha, E.APROBADA, horaFin, horaInicio, excluirId || '');
  return !!fila;
}

export function crear(datos) {
  const errores = validarReserva(datos);
  if (errores.length) throw new AppError('Datos de reserva no válidos.', 422, errores);

  const usuario = usuarios.obtener(datos.usuarioId);
  if (!usuario || !usuario.activo) throw new AppError('El solicitante no existe o está inactivo.', 422, [{ campo: 'usuarioId', mensaje: 'Solicitante no válido.' }]);
  const ambiente = ambientes.obtener(datos.ambienteId);
  if (!ambiente) throw new AppError('El ambiente no existe.', 422, [{ campo: 'ambienteId', mensaje: 'Ambiente no válido.' }]);
  if (ambiente.estado !== 'Disponible') throw new AppError(`El ambiente está en estado "${ambiente.estado}".`, 409);

  if (hayConflicto(datos)) throw new AppError('El ambiente ya tiene una reserva aprobada en ese horario.', 409, [{ campo: 'horaInicio', mensaje: 'Horario no disponible.' }]);

  const id = randomUUID();
  db.prepare(`INSERT INTO reserva (id, fecha, hora_inicio, hora_fin, motivo, estado, usuario_id, ambiente_id)
              VALUES (?,?,?,?,?,?,?,?)`)
    .run(id, datos.fecha, datos.horaInicio, datos.horaFin, datos.motivo.trim(), E.PENDIENTE, datos.usuarioId, datos.ambienteId);
  return obtener(id);
}

// Transiciones permitidas: Pendiente -> Aprobada | Rechazada | Cancelada ; Aprobada -> Cancelada
const TRANSICIONES = {
  [E.PENDIENTE]: [E.APROBADA, E.RECHAZADA, E.CANCELADA],
  [E.APROBADA]: [E.CANCELADA],
  [E.RECHAZADA]: [],
  [E.CANCELADA]: [],
};

export function cambiarEstado(id, nuevoEstado, actor) {
  if (!Object.values(E).includes(nuevoEstado)) throw new AppError('Estado no válido.', 422, [{ campo: 'estado', mensaje: 'Estado no válido.' }]);
  const reserva = obtener(id);

  // RN-06
  if (reserva.estado === E.RECHAZADA) throw new AppError('Una reserva rechazada no puede modificarse.', 409);

  // RN-05
  const esAdmin = actor?.rol === ROLES.ADMIN;
  if ([E.APROBADA, E.RECHAZADA].includes(nuevoEstado) && !esAdmin)
    throw new AppError('Solo el administrador puede aprobar o rechazar reservas.', 403);
  if (nuevoEstado === E.CANCELADA && !esAdmin && actor?.id !== reserva.usuarioId)
    throw new AppError('Solo el administrador o el solicitante pueden cancelar la reserva.', 403);

  if (!TRANSICIONES[reserva.estado].includes(nuevoEstado))
    throw new AppError(`No se puede pasar de "${reserva.estado}" a "${nuevoEstado}".`, 409);

  // RN-01 al aprobar
  if (nuevoEstado === E.APROBADA && hayConflicto({ ...reserva, excluirId: reserva.id }))
    throw new AppError('Ya existe otra reserva aprobada para ese ambiente, fecha y horario.', 409);

  db.prepare('UPDATE reserva SET estado = ? WHERE id = ?').run(nuevoEstado, id);
  return obtener(id);
}

// RN-06: solo se edita una reserva Pendiente
export function actualizar(id, datos) {
  const reserva = obtener(id);
  if (reserva.estado === E.RECHAZADA) throw new AppError('Una reserva rechazada no puede modificarse.', 409);
  if (reserva.estado !== E.PENDIENTE) throw new AppError('Solo se pueden modificar reservas pendientes.', 409);
  const nuevos = { ...reserva, ...datos };
  const errores = validarReserva(nuevos);
  if (errores.length) throw new AppError('Datos de reserva no válidos.', 422, errores);
  db.prepare('UPDATE reserva SET fecha=?, hora_inicio=?, hora_fin=?, motivo=?, ambiente_id=? WHERE id=?')
    .run(nuevos.fecha, nuevos.horaInicio, nuevos.horaFin, nuevos.motivo.trim(), nuevos.ambienteId, id);
  return obtener(id);
}

// RF-08
export function indicadores() {
  const conteo = (estado) => db.prepare('SELECT COUNT(*) c FROM reserva WHERE estado = ?').get(estado).c;
  const top = db.prepare(`
    SELECT a.nombre, COUNT(*) total FROM reserva r JOIN ambiente a ON a.id = r.ambiente_id
    GROUP BY a.id ORDER BY total DESC, a.nombre LIMIT 1`).get();
  return {
    total: db.prepare('SELECT COUNT(*) c FROM reserva').get().c,
    pendientes: conteo(E.PENDIENTE),
    aprobadas: conteo(E.APROBADA),
    rechazadas: conteo(E.RECHAZADA),
    canceladas: conteo(E.CANCELADA),
    ambienteMasUtilizado: top ? { nombre: top.nombre, reservas: top.total } : null,
  };
}
