import { randomUUID } from 'node:crypto';
import { db } from '../db.js';
import { AppError } from '../utils/AppError.js';
import { validarAmbiente } from '../validators/ambiente.validator.js';

const mapear = (r) => r && ({ id: r.id, nombre: r.nombre, tipo: r.tipo, capacidad: r.capacidad, ubicacion: r.ubicacion, estado: r.estado, responsableId: r.responsable_id });

export const listar = () => db.prepare('SELECT * FROM ambiente ORDER BY nombre').all().map(mapear);

export const obtener = (id) => mapear(db.prepare('SELECT * FROM ambiente WHERE id = ?').get(id));

export function crear(d) {
  const errores = validarAmbiente(d);
  if (errores.length) throw new AppError('Datos de ambiente no válidos.', 422, errores);
  if (db.prepare('SELECT 1 FROM ambiente WHERE nombre = ?').get(d.nombre.trim()))
    throw new AppError('Ya existe un ambiente con ese nombre.', 409, [{ campo: 'nombre', mensaje: 'Nombre ya registrado.' }]);
  const id = randomUUID();
  db.prepare('INSERT INTO ambiente (id, nombre, tipo, capacidad, ubicacion, estado, responsable_id) VALUES (?,?,?,?,?,?,?)')
    .run(id, d.nombre.trim(), d.tipo.trim(), Number(d.capacidad), d.ubicacion.trim(), d.estado || 'Disponible', d.responsableId || null);
  return obtener(id);
}
