import { HORARIO } from '../config/constants.js';
import { esFecha, esHora, esTextoValido, hoyISO } from './common.js';

// RN-02, RN-03, RN-04
export function validarReserva(d = {}) {
  const e = [];
  if (!d.usuarioId) e.push({ campo: 'usuarioId', mensaje: 'El solicitante es obligatorio.' });
  if (!d.ambienteId) e.push({ campo: 'ambienteId', mensaje: 'El ambiente es obligatorio.' });
  if (!esTextoValido(d.motivo, 500)) e.push({ campo: 'motivo', mensaje: 'El motivo es obligatorio (máx. 500 caracteres).' });

  if (!esFecha(d.fecha)) e.push({ campo: 'fecha', mensaje: 'Ingrese una fecha válida (AAAA-MM-DD).' });
  else if (d.fecha < hoyISO()) e.push({ campo: 'fecha', mensaje: 'La fecha no puede ser anterior a hoy.' });

  const inicioOk = esHora(d.horaInicio);
  const finOk = esHora(d.horaFin);
  if (!inicioOk) e.push({ campo: 'horaInicio', mensaje: 'Ingrese una hora de inicio válida (HH:MM).' });
  if (!finOk) e.push({ campo: 'horaFin', mensaje: 'Ingrese una hora de fin válida (HH:MM).' });

  if (inicioOk && finOk) {
    if (d.horaFin <= d.horaInicio) e.push({ campo: 'horaFin', mensaje: 'La hora de fin debe ser mayor que la hora de inicio.' }); // RN-03
    if (d.horaInicio < HORARIO.INICIO || d.horaFin > HORARIO.FIN)
      e.push({ campo: 'horaInicio', mensaje: `Las reservas solo se permiten entre ${HORARIO.INICIO} y ${HORARIO.FIN}.` }); // RN-04
  }
  return e;
}
