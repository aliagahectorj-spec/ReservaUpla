import { ROLES } from '../config/constants.js';
import { esTextoValido, esCorreo } from './common.js';

export function validarUsuario(d = {}) {
  const e = [];
  if (!esTextoValido(d.nombreCompleto, 150)) e.push({ campo: 'nombreCompleto', mensaje: 'El nombre es obligatorio (máx. 150 caracteres).' });
  if (!esCorreo(d.correo) || d.correo.length > 150) e.push({ campo: 'correo', mensaje: 'Ingrese un correo válido.' });
  if (!Object.values(ROLES).includes(d.rol)) e.push({ campo: 'rol', mensaje: 'Rol no válido.' });
  return e;
}
