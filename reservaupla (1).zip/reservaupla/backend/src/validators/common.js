export const esTextoValido = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max;
export const esCorreo = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || '');
export const esFecha = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v || '') && !Number.isNaN(Date.parse(v));
export const esHora = (v) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v || '');
export const hoyISO = () => new Date().toISOString().slice(0, 10);
