import { ESTADOS_AMBIENTE } from '../config/constants.js';
import { esTextoValido } from './common.js';

export function validarAmbiente(d = {}) {
  const e = [];
  if (!esTextoValido(d.nombre, 100)) e.push({ campo: 'nombre', mensaje: 'El nombre es obligatorio (máx. 100 caracteres).' });
  if (!esTextoValido(d.tipo, 50)) e.push({ campo: 'tipo', mensaje: 'El tipo es obligatorio (máx. 50 caracteres).' });
  if (!Number.isInteger(Number(d.capacidad)) || Number(d.capacidad) <= 0) e.push({ campo: 'capacidad', mensaje: 'La capacidad debe ser un entero mayor a 0.' });
  if (!esTextoValido(d.ubicacion, 100)) e.push({ campo: 'ubicacion', mensaje: 'La ubicación es obligatoria (máx. 100 caracteres).' });
  if (d.estado && !ESTADOS_AMBIENTE.includes(d.estado)) e.push({ campo: 'estado', mensaje: 'Estado de ambiente no válido.' });
  return e;
}
