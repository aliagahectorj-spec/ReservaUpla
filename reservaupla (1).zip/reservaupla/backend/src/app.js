import express from 'express';
import cors from 'cors';
import routes from './routes/index.js';
import { actor } from './middlewares/actor.js';
import { errorHandler, noEncontrado } from './middlewares/errorHandler.js';

export const app = express();
app.use(cors());
app.use(express.json());
app.use('/api', actor, routes);
app.use(noEncontrado);
app.use(errorHandler);
