import * as service from '../services/reserva.service.js';

export const listar = (req, res) => res.json(service.listar(req.query));
export const obtener = (req, res) => res.json(service.obtener(req.params.id));
export const crear = (req, res) => res.status(201).json(service.crear(req.body));
export const actualizar = (req, res) => res.json(service.actualizar(req.params.id, req.body));
export const cambiarEstado = (req, res) => res.json(service.cambiarEstado(req.params.id, req.body.estado, req.actor));
export const indicadores = (_req, res) => res.json(service.indicadores());
