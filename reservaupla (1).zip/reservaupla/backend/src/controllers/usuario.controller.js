import * as service from '../services/usuario.service.js';

export const listar = (_req, res) => res.json(service.listar());
export const crear = (req, res) => res.status(201).json(service.crear(req.body));
