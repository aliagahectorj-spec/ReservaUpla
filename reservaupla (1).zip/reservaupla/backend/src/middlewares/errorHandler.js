import { AppError } from '../utils/AppError.js';

export function noEncontrado(_req, res) {
  res.status(404).json({ mensaje: 'Ruta no encontrada.' });
}

export function errorHandler(err, _req, res, _next) {
  if (err instanceof AppError) return res.status(err.status).json({ mensaje: err.message, detalles: err.detalles });
  console.error(err);
  res.status(500).json({ mensaje: 'Error interno del servidor.' });
}
