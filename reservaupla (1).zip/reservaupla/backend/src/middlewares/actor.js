import * as usuarios from '../services/usuario.service.js';

// Identifica al usuario que ejecuta la acción mediante la cabecera x-usuario-id.
// (Simulación simple de sesión: el curso no exige autenticación real.)
export function actor(req, _res, next) {
  const id = req.header('x-usuario-id');
  req.actor = id ? usuarios.obtener(id) : null;
  next();
}
