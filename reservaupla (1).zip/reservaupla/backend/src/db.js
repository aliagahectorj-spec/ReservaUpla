import Database from 'better-sqlite3';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const dir = path.dirname(fileURLToPath(import.meta.url));
const dbFile = process.env.DB_FILE || path.join(dir, '../../database/reservaupla.db');

export const db = new Database(dbFile);
db.pragma('foreign_keys = ON');
db.exec(readFileSync(path.join(dir, '../../database/schema.sql'), 'utf8'));
