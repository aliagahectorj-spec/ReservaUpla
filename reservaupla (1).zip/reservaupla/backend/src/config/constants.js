// Constantes del dominio (una sola fuente de verdad)
export const ROLES = { SOLICITANTE: 'Solicitante', ADMIN: 'Administrador', RESPONSABLE: 'ResponsableAmbiente' };
export const ESTADOS_RESERVA = { PENDIENTE: 'Pendiente', APROBADA: 'Aprobada', RECHAZADA: 'Rechazada', CANCELADA: 'Cancelada' };
export const ESTADOS_AMBIENTE = ['Disponible', 'Mantenimiento', 'Inactivo'];
export const HORARIO = { INICIO: '07:00', FIN: '22:00' }; // RN-04
export const PORT = process.env.PORT || 3000;
