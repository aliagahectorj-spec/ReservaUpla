import { app } from './app.js';
import { PORT } from './config/constants.js';

app.listen(PORT, () => console.log(`ReservaUPLA API en http://localhost:${PORT}/api`));
