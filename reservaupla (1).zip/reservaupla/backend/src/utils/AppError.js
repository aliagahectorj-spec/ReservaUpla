// Error controlado con código HTTP y detalle opcional
export class AppError extends Error {
  constructor(message, status = 400, detalles = []) {
    super(message);
    this.status = status;
    this.detalles = detalles;
  }
}
