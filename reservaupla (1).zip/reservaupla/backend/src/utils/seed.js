// Datos de ejemplo: npm run seed
import { db } from '../db.js';
import * as usuarios from '../services/usuario.service.js';
import * as ambientes from '../services/ambiente.service.js';

if (db.prepare('SELECT COUNT(*) c FROM usuario').get().c === 0) {
  usuarios.crear({ nombreCompleto: 'Administrador UPLA', correo: 'admin@upla.edu.pe', rol: 'Administrador' });
  usuarios.crear({ nombreCompleto: 'María Quispe Huamán', correo: 'mquispe@upla.edu.pe', rol: 'Solicitante' });
  usuarios.crear({ nombreCompleto: 'Carlos Rojas Ccanto', correo: 'crojas@upla.edu.pe', rol: 'Solicitante' });
  const rosa = usuarios.crear({ nombreCompleto: 'Rosa Meza Paucar', correo: 'rmeza@upla.edu.pe', rol: 'ResponsableAmbiente' });
  ambientes.crear({ nombre: 'Laboratorio de Cómputo 1', tipo: 'Laboratorio', capacidad: 30, ubicacion: 'Pabellón B - Piso 2', responsableId: rosa.id });
  ambientes.crear({ nombre: 'Auditorio Central', tipo: 'Auditorio', capacidad: 250, ubicacion: 'Edificio principal' });
  ambientes.crear({ nombre: 'Sala de Reuniones 3', tipo: 'Sala', capacidad: 12, ubicacion: 'Pabellón A - Piso 1' });
  console.log('Datos de ejemplo cargados.');
} else console.log('La base de datos ya tiene datos; no se cargó nada.');
