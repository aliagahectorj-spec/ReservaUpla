import { Router } from 'express';
import * as u from '../controllers/usuario.controller.js';
import * as a from '../controllers/ambiente.controller.js';
import * as r from '../controllers/reserva.controller.js';

const router = Router();

router.get('/usuarios', u.listar);
router.post('/usuarios', u.crear);

router.get('/ambientes', a.listar);
router.post('/ambientes', a.crear);

router.get('/reservas/indicadores', r.indicadores); // antes de /:id
router.get('/reservas', r.listar);
router.post('/reservas', r.crear);
router.get('/reservas/:id', r.obtener);
router.put('/reservas/:id', r.actualizar);
router.patch('/reservas/:id/estado', r.cambiarEstado);

export default router;
