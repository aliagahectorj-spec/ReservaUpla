# ReservaUPLA

Sistema web para gestionar reservas de ambientes universitarios (Construcción de Software, semanas 01–09).

**Stack:** Node.js 20+ · Express · SQLite (better-sqlite3) · React + Vite

## Cómo ejecutarlo en VS Code (terminal)

1. Abrir la carpeta: `File > Open Folder…` → `reservaupla`.
2. Abrir la terminal integrada: `Ctrl + ñ` (o `Terminal > New Terminal`).

**Terminal 1 – Backend**
```bash
cd backend
npm install
npm run seed      # opcional: datos de ejemplo
npm run dev       # http://localhost:3000/api
```

**Terminal 2 – Frontend** (botón `+` de la terminal para abrir otra)
```bash
cd frontend
npm install
npm run dev       # http://localhost:5173
```

**Pruebas (evidencia de validaciones)**
```bash
cd backend
npm test
```

> Atajo: `Terminal > Run Task… > Iniciar todo` levanta backend y frontend a la vez.

## Uso rápido
1. Elija en la cabecera el **Usuario actual** (use «Administrador UPLA» para aprobar/rechazar).
2. Cree reservas en **Nueva reserva**; revise estados en **Reservas**; vea indicadores en **Dashboard**.

## Estructura
```
backend/    API (routes, controllers, services, validators, tests)
frontend/   React (components, pages, hooks, services, validators)
database/   schema.sql (el archivo .db se crea solo al iniciar el backend)
docs/       análisis, ciclo de vida, estándares e informe técnico
```

## Comandos Git sugeridos
```bash
git init
git checkout -b develop
git add . && git commit -m "feat: proyecto inicial ReservaUPLA"
```
